package com.travelgo.backend_travelgo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendTravelgoApplicationTests {

	@Test
	void contextLoads() {
	}

}
